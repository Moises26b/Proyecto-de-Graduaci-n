namespace Proyecto_de_Diseño_y_Desarrollo_de_Sistemas.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
